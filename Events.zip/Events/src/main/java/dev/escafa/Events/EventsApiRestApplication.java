package dev.escafa.Events;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventsApiRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventsApiRestApplication.class, args);
	}

}
