package dev.escafa.Events;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventsApiRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
